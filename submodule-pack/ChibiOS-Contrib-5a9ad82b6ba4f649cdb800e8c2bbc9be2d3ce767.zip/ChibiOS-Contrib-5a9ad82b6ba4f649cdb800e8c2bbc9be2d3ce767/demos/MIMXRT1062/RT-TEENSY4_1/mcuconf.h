/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#ifndef _MCUCONF_H_
#define _MCUCONF_H_

#define MIMXRT1062_MCUCONF

/* The NXP USB stack uses more stack space than the default 256 byte of thread
 * working area for the test command can fit, so make some more room: */
#define SHELL_CMD_TEST_WA_SIZE              THD_WORKING_AREA_SIZE(1024)

#endif /* _MCUCONF_H_ */
